
<?php 
///definir ruta

define("RUTA_BASE", dirname(realpath(__FILE__))."/");
//echo "en index.php " .RUTA_BASE;
include "libreria/core.php";

 ?>