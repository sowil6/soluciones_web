
<!--<head>-->
	<base />
<meta charset="utf-8">
<!--<link rel="shortcut icon" href= "./../ImgSistema/icono.ico" type="image/x-icon">-->
 <link rel="shortcut icon" href= "./ImgSistema/icono.png" type="image/png">
<title>Corporación Educativa de Formación Integral del Caribe - CEFIC </title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Drop-Down Navigation: Touch-Friendly and Responsive demo by Osvaldas Valutis</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="robots" content="all">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--</head>-->
