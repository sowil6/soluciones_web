<!doctype html>
<html><head>
<meta charset="utf-8">
<!-- TemplateBeginEditable name="doctitle" -->
<title>Corporación Educativa de Formación Integral del Caribe - CEFIC </title>
<!-- TemplateEndEditable 
-->
<!--<link href="../Styles/bootstrapCSS/bootstrap.css" rel="stylesheet" type="text/css">
<script src="../Scripts/jquery-css-transform.js" type="text/javascript"></script>-->
 


<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->

</head>

<body>

<div class="containerCeficc">
  <header>
  
  <?php include("../includes/cabecera.php")?>
   </header>

  <!-- TemplateBeginEditable name="EditRegionUnaColumna" -->
  <article class="contentUnaColumna">
      

  
  </article>
  <!-- TemplateEndEditable --><!-- end .content -->

  <footer>
     <?php include("../includes/footer.php")?>
     </footer>
 </div> <!-- end .container -->
 
</body>
</html>